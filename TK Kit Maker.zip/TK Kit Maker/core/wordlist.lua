-- Random two-word kit name generator, used when a KitDef has no name_prefix.

local M = {}

local words = nil

local function default_words()
  return {
    "Funky", "Blue", "Bottle", "Lobster", "Hot", "Summer", "Wild", "Static",
    "Neon", "Rust", "Velvet", "Broken", "Golden", "Dusty", "Electric", "Quiet",
  }
end

local function load_words(script_path)
  if words then return words end
  words = {}
  local path = (script_path or "") .. "data/words.txt"
  local f = io.open(path, "r")
  if f then
    for line in f:lines() do
      local word = line:gsub("%s+$", ""):gsub("^%s+", "")
      if #word > 0 then words[#words + 1] = word end
    end
    f:close()
  end
  if #words == 0 then words = default_words() end
  return words
end

function M.random_name(script_path)
  local list = load_words(script_path)
  local a = list[math.random(#list)]
  local b = list[math.random(#list)]
  return a .. " " .. b
end

-- Forces the word list to be re-read from disk on the next random_name() call.
function M.reload()
  words = nil
end

return M
