local r = reaper
local Theme         = require("core.theme")
local ExplosionView = require("ui.explosion_view")
local BuilderView   = require("ui.builder_view")
local ExportDialog  = require("ui.export_dialog")

local M = {}

function M.init(app)
  app.view = "explosion"
  ExplosionView.init(app)
  BuilderView.init(app)
  ExportDialog.init(app)
end

local function tab_button(ctx, label, tip, active, width)
  local c = Theme.colors
  if active then
    r.ImGui_PushStyleColor(ctx, r.ImGui_Col_Button(), c.accent_soft)
    r.ImGui_PushStyleColor(ctx, r.ImGui_Col_ButtonHovered(), c.accent_soft)
    r.ImGui_PushStyleColor(ctx, r.ImGui_Col_ButtonActive(), c.accent_soft)
    r.ImGui_PushStyleColor(ctx, r.ImGui_Col_Border(), c.accent)
    r.ImGui_PushStyleColor(ctx, r.ImGui_Col_Text(), 0xFFFFFFFF)
  else
    r.ImGui_PushStyleColor(ctx, r.ImGui_Col_Button(), 0x00000000)
    r.ImGui_PushStyleColor(ctx, r.ImGui_Col_ButtonHovered(), c.frame_bg)
    r.ImGui_PushStyleColor(ctx, r.ImGui_Col_ButtonActive(), c.frame_hover)
    r.ImGui_PushStyleColor(ctx, r.ImGui_Col_Border(), c.border)
    r.ImGui_PushStyleColor(ctx, r.ImGui_Col_Text(), c.text_dim)
  end
  local clicked = r.ImGui_Button(ctx, label, width, 34)
  if tip and r.ImGui_IsItemHovered(ctx) then r.ImGui_SetTooltip(ctx, tip) end
  r.ImGui_PopStyleColor(ctx, 5)
  return clicked
end

local function close_button(ctx, size)
  local dl = r.ImGui_GetWindowDrawList(ctx)
  local x, y = r.ImGui_GetCursorScreenPos(ctx)
  local clicked = r.ImGui_InvisibleButton(ctx, "##tk_close", size, size)
  local hovered = r.ImGui_IsItemHovered(ctx)
  local cx, cy = x + size * 0.5, y + size * 0.5
  local rad = size * 0.5
  local col = hovered and Theme.colors.danger or 0xC85A60FF
  r.ImGui_DrawList_AddCircleFilled(dl, cx, cy, rad, col)
  if hovered and r.ImGui_SetTooltip then r.ImGui_SetTooltip(ctx, "Close") end
  return clicked
end

local function draw_header(app)
  local ctx = app.ctx
  local pushed = Theme.push_h1(ctx)
  r.ImGui_TextColored(ctx, Theme.colors.accent, "TK Kit Maker")
  Theme.pop_font(ctx, pushed)

  local theme_w = 140
  local close_size = 16
  local gap = 10
  r.ImGui_SameLine(ctx)
  local avail = select(1, r.ImGui_GetContentRegionAvail(ctx))
  local cluster_w = theme_w + gap + close_size
  r.ImGui_SetCursorPosX(ctx, r.ImGui_GetCursorPosX(ctx) + math.max(0, avail - cluster_w))
  r.ImGui_AlignTextToFramePadding(ctx)
  Theme.theme_combo(ctx, theme_w)

  r.ImGui_SameLine(ctx, 0, gap)
  local fh = r.ImGui_GetFrameHeight(ctx)
  r.ImGui_SetCursorPosY(ctx, r.ImGui_GetCursorPosY(ctx) + (fh - close_size) * 0.5)
  if close_button(ctx, close_size) then
    app.request_close = true
  end

  r.ImGui_Spacing(ctx)

  local avail_w = select(1, r.ImGui_GetContentRegionAvail(ctx))
  local spacing = 8
  local half = (avail_w - spacing) * 0.5
  if tab_button(ctx, "Folder Explosion", "Surprise me with a folder", app.view == "explosion", half) then
    app.view = "explosion"
  end
  r.ImGui_SameLine(ctx, 0, spacing)
  if tab_button(ctx, "Kit Builder", "I define the structure, surprise me with the contents", app.view == "builder", half) then
    app.view = "builder"
  end

  r.ImGui_Dummy(ctx, 0, 4)
  r.ImGui_Separator(ctx)
  r.ImGui_Dummy(ctx, 0, 4)
end

function M.frame(app)
  local ctx = app.ctx
  Theme.init(ctx)

  r.ImGui_SetNextWindowSize(ctx, 560, 780, r.ImGui_Cond_FirstUseEver())
  if r.ImGui_SetNextWindowSizeConstraints then
    r.ImGui_SetNextWindowSizeConstraints(ctx, 560, 480, 560, 100000)
  end

  local theme_stack = Theme.push(ctx)
  local window_flags = r.ImGui_WindowFlags_NoTitleBar() | r.ImGui_WindowFlags_NoScrollbar() | r.ImGui_WindowFlags_NoScrollWithMouse()
  local visible, open = r.ImGui_Begin(ctx, app.script_name, true, window_flags)

  if visible then
    local body_pushed = Theme.push_body(ctx)
    draw_header(app)

    r.ImGui_PushStyleColor(ctx, r.ImGui_Col_ChildBg(), 0x00000000)
    r.ImGui_PushStyleVar(ctx, r.ImGui_StyleVar_WindowPadding(), 0, 0)
    local body_visible = r.ImGui_BeginChild(ctx, "##tk_body", 0, 0, 0)
    r.ImGui_PopStyleVar(ctx)
    if body_visible then
      if app.view == "explosion" then
        ExplosionView.draw(app)
      else
        BuilderView.draw(app)
        if app.kitdef then
          ExportDialog.draw(app)
        end
      end
      r.ImGui_EndChild(ctx)
    end
    r.ImGui_PopStyleColor(ctx)

    if r.ImGui_IsKeyPressed(ctx, r.ImGui_Key_Escape()) then
      app.request_close = true
    end

    Theme.pop_font(ctx, body_pushed)
    r.ImGui_End(ctx)
  end

  Theme.pop(ctx, theme_stack)

  if app.request_close then open = false end
  return open
end

return M
